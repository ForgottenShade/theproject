// Electron main process: opens one window running the game from index.html.
// `npm start` plays it. `npm run selftest` plays 5 games with random keys and
// exits non-zero if the page logged errors. (No screenshot: on some Windows GPUs
// capturePage never resolves, which used to hang the test.)
const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');

const SELFTEST = process.argv.includes('--selftest');

function createWindow() {
  const win = new BrowserWindow({
    width: 1100,
    height: 640,
    backgroundColor: '#000000',
    title: 'Ananas aus Caracas',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  if (SELFTEST) runSelftest(win);
  else win.loadFile(path.join(__dirname, 'index.html'));
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function runSelftest(win) {
  // Never hang: give up after 90 seconds.
  setTimeout(() => { console.log('SELFTEST FAILED (timed out)'); app.exit(1); }, 90000).unref();
  const errors = [];
  win.webContents.on('console-message', (e) => {
    if (e.level === 'error') errors.push(e.message);
  });
  win.webContents.on('preload-error', (e, p, err) => errors.push(String(err)));
  await win.loadFile(path.join(__dirname, 'index.html'));
  const js = (code) => win.webContents.executeJavaScript(code);
  await js(`window.addEventListener('error', (e) => console.error('page error: ' + e.message))`);
  const keys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown', 'w', 'a', 's', 'd', 'e', 'i'];
  const key = (k) => js(`window.dispatchEvent(new KeyboardEvent('keydown', { key: ${JSON.stringify(k)}, cancelable: true }))`);
  const press = async (n) => {
    for (let i = 0; i < n; i++) await key(keys[Math.floor(Math.random() * keys.length)]);
  };
  const shot = async (name) => {
    if (!process.argv.includes('--shots')) return; // capturePage can hang on some Windows GPUs
    await wait(300);
    fs.mkdirSync(path.join(__dirname, 'selftest-output'), { recursive: true });
    fs.writeFileSync(path.join(__dirname, 'selftest-output', name), (await win.webContents.capturePage()).toPNG());
  };
  const check = (ok, what) => { console.log(`${ok ? 'ok  ' : 'FAIL'} ${what}`); if (!ok) errors.push('check failed: ' + what); };

  for (let round = 0; round < 3; round++) {
    // Main menu -> new world
    if (round === 0) await shot('menu.png');
    await js(`document.getElementById('menu-new').click()`);
    check(await js(`Game.running && Game.level.name === 'overworld' && document.getElementById('menu').hidden`), `round ${round + 1}: menu starts a world`);
    await shot(`overworld-${round + 1}.png`);
    await press(80);

    // Standing on the entrance does nothing until E is pressed.
    await js(`InventoryUI.toggle(false); Menu.close(); Game.player._x = Game.overworld.entrance[0]; Game.player._y = Game.overworld.entrance[1]; Game.render()`);
    check(await js(`Game.level.name`) === 'overworld', 'standing on the entrance does not enter');
    await key('e');
    check(await js(`Game.level.name`) === 'dungeon', 'E on the entrance enters the dungeon');
    check(await js(`Object.keys(Game.dungeon.memory).length < Object.keys(Game.dungeon.cells).length`), 'fog of war hides unseen cells');
    await shot(`dungeon-${round + 1}.png`);

    // Open a chest with loot and move things into the bag.
    const before = await js(`Game.player.inventory.slots.filter(Boolean).length`);
    await js(`(() => { const k = Object.keys(Game.dungeon.chests).find(k => Game.dungeon.chests[k].count('ananas') === 0); const p = k.split(',').map(Number); Game.player._x = p[0]; Game.player._y = p[1]; Game.render(); })()`);
    await key('e');
    check(await js(`InventoryUI.chest !== null && !document.getElementById('chest').hidden`), 'E on a chest opens the chest window');
    await shot(`chest-${round + 1}.png`);
    await js(`InventoryUI.move('chest', InventoryUI.chest.slots.findIndex(Boolean), 'inv', Game.player.inventory.slots.findIndex(s => !s))`);
    check(await js(`Game.player.inventory.slots.filter(Boolean).length`) >= before, 'moving an item from chest to bag');
    await js(`InventoryUI.takeAll()`);
    await key('Escape');
    check(await js(`InventoryUI.chest === null`), 'Esc closes the chest');

    // Stacking: adding bread twice keeps one stack.
    check(await js(`(() => { const c = new Container('t', 4, 4); c.add('bread', 5); c.add('bread', 7); return c.slots.filter(Boolean).length === 1 && c.count('bread') === 12; })()`), 'items stack');

    if (round < 2) await press(120); // the last round skips wandering so Pedro can't end it before the win check
    console.log(`round ${round + 1}: ${await js(`[Game.level.name, Game.running, document.getElementById('message').textContent].join(' | ')`)}`);

    // Grab the ananas to win (if Pedro hasn't already won).
    if (await js(`Game.running && Game.level.name === 'dungeon'`)) {
      await js(`(() => { const k = Object.keys(Game.dungeon.chests).find(k => Game.dungeon.chests[k].count('ananas') > 0); const p = k.split(',').map(Number); Game.player._x = p[0]; Game.player._y = p[1]; InventoryUI.openChest(Game.dungeon.chests[k]); InventoryUI.quickMove('chest', Game.dungeon.chests[k].slots.findIndex(s => s && s.id === 'ananas')); })()`);
      check(await js(`!Game.running`), 'taking the ananas wins');
    }
    await key('Escape'); // back to the menu
  }
  await wait(200);
  if (errors.length) console.log('Errors:\n' + errors.join('\n'));
  console.log(errors.length ? 'SELFTEST FAILED' : 'SELFTEST PASSED');
  app.exit(errors.length ? 1 : 0);
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
