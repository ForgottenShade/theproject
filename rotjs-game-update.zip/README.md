# Ananas aus Caracas

The small roguelike from the three-part
[RogueBasin rot.js tutorial](https://roguebasin.com/index.php/Rot.js_tutorial),
built with [rot.js](https://ondras.github.io/rot.js/hp/) and running as an Electron desktop app.

A main menu lets you enter a new world. You start on an overworld of water (`~`), plains (`.`), hills (`n`) and mountains (`^`),
grown with `ROT.Map.Cellular`. Mountains can't be crossed. Somewhere on the land is the
dungeon entrance (`>`): stand on it and press E to go down. Inside, rooms have wood or stone
floors, doors (`+`) and brick walls, and you only see what's in your line of sight. Places you've
seen stay on the map, dimmed, as you last saw them. Ten chests (`*`) hold random fantasy loot, and
one of them holds the ananas: get it into your bag to win. Find it before Pedro (`P`), its angry
owner, catches you. The stairs (`<`) take you back outside.

## Run it

Needs Node.js 22.12 or newer.

```sh
npm install
npm start
```

- Move: arrow keys, or the numpad (Home / PgUp / End / PgDn for diagonals)
- Use (enter the dungeon on `>`, climb out on `<`, open a chest you stand on): E, Enter or Space
- Bag (4x4, items stack): I. Esc closes windows, or opens the menu
- In a chest window: drag items into your bag (or back), shift-click or double-click to move a
  whole stack, or press Take all. Hover an item to read about it.

`npm run selftest` plays through 3 worlds (menu, overworld, entrance, chests, bag, win) and fails on any page error or failed check.

## Where each tutorial part lives

| Tutorial part | What it adds | File |
|---|---|---|
| Part 1 | `ROT.Display`, `ROT.Map.Digger` dungeon, boxes | `src/game/Map.js`, `src/game/Game.js` |
| Part 2 | Player, `ROT.Scheduler.Simple` + `ROT.Engine`, keyboard movement with `ROT.DIRS` | `src/game/Player.js`, `src/game/Entity.js`, `src/game/Game.js` |
| Part 3 | Opening boxes, Pedro chasing you with `ROT.Path.AStar` | `src/game/Player.js`, `src/systems/AI.js` |

| Beyond the tutorial | Cellular-automaton overworld, dungeon entrance and stairs | `src/game/Overworld.js`, `src/game/Game.js` |
| Beyond the tutorial | Wood/stone floors, doors, textured walls | `src/game/Tiles.js`, `src/game/Map.js` |
| Beyond the tutorial | Fantasy item list and chest loot | `src/game/Items.js` |
| Beyond the tutorial | Stacking containers (bag, chests) | `src/game/Inventory.js` |
| Beyond the tutorial | Bag and chest windows, drag and drop | `src/ui/InventoryUI.js`, `src/ui/style.css` |
| Beyond the tutorial | Line of sight, fog of war, map memory | `src/systems/FOV.js`, `Game.render` in `src/game/Game.js` |
| Beyond the tutorial | Main menu | `src/ui/UI.js`, `index.html` |

`src/ui/UI.js` shows messages under the map, and `src/main.js` starts the game.
`main.js` in the root is the Electron window.

## Small differences from the tutorial

- Keys use `event.key` instead of the deprecated numeric `keyCode`, and arrow keys work as well as the numpad.
- Messages appear under the map instead of in `alert()` pop-ups.
- You can't step onto Pedro (one of the tutorial's listed known issues), and R starts a new dungeon.
