// Part 3: Pedro, the angry owner of the ananas, who hunts the player with A*.
// He lives in the dungeon and follows you through doors, but not up the stairs.
var Pedro = function (x, y) {
  Entity.call(this, x, y, "P", "#ff3030");
};
Pedro.prototype = Object.create(Entity.prototype);
Pedro.prototype.constructor = Pedro;

Pedro.prototype.act = function () {
  var x = Game.player.getX();
  var y = Game.player.getY();

  var passableCallback = function (x, y) {
    var cell = Game.cellAt(x, y);
    return !!(cell && cell.passable);
  };
  // Topology 4: Pedro can't move diagonally, which gives the player a chance.
  var astar = new ROT.Path.AStar(x, y, passableCallback, { topology: 4 });

  var path = [];
  astar.compute(this._x, this._y, function (x, y) { path.push([x, y]); });

  path.shift(); // the first cell is where Pedro already stands
  if (path.length === 0) { return; }
  if (path.length === 1) {
    Game.gameOver("Game over - you were captured by Pedro!");
  } else {
    this._moveTo(path[0][0], path[0][1]);
  }
};
