// Small UI helpers: the message line, the end-of-game banner, the main menu,
// and a flag that tells the player whether keys should go to a window instead.
var UI = {
  show: function (text) {
    document.getElementById("message").textContent = text;
  },
  clear: function () {
    this.show("");
  },

  // True while the main menu or a chest window is open (the inventory alone doesn't block walking).
  isBlocking: function () {
    return Menu.isOpen() || InventoryUI.chest !== null;
  },

  banner: function (title, sub) {
    var el = document.getElementById("banner");
    el.querySelector("h2").textContent = title;
    el.querySelector("p").textContent = sub;
    el.hidden = false;
    setTimeout(function () { el.hidden = true; }, 2500);
  }
};

// The main menu.
var Menu = {
  el: null,
  isOpen: function () { return !!this.el && !this.el.hidden; },

  init: function () {
    this.el = document.getElementById("menu");
    var self = this;
    document.getElementById("menu-new").addEventListener("click", function () { self.newWorld(); });
    document.getElementById("menu-resume").addEventListener("click", function () { self.close(); });
    document.getElementById("menu-controls").addEventListener("click", function () {
      var c = document.getElementById("menu-help");
      c.hidden = !c.hidden;
    });
    document.getElementById("menu-quit").addEventListener("click", function () { window.close(); });
    this.open();
  },

  open: function () {
    document.getElementById("menu-resume").hidden = !Game.running;
    this.el.hidden = false;
    document.getElementById(Game.running ? "menu-resume" : "menu-new").focus();
  },

  close: function () {
    this.el.hidden = true;
    if (document.activeElement) { document.activeElement.blur(); }
  },

  newWorld: function () {
    this.close();
    Game.newWorld();
  }
};
