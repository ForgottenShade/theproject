// The inventory window (4x4 bag) and the chest window, with drag and drop between them.
//   drag a stack onto an empty slot      -> it moves there
//   drag onto the same (stackable) item  -> they merge, up to the stack limit
//   drag onto a different item           -> the two swap places
//   shift-click (or double-click) a stack -> it jumps to the other window
var InventoryUI = {
  open: false,  // is the bag window showing?
  chest: null,  // the chest being looted, if any

  init: function () {
    var self = this;
    document.getElementById("chest-takeall").addEventListener("click", function () { self.takeAll(); });
    document.getElementById("chest-close").addEventListener("click", function () { self.closeChest(); });
    document.getElementById("inv-close").addEventListener("click", function () { self.toggle(false); });
    this.tooltip = document.getElementById("tooltip");
  },

  toggle: function (show) {
    this.open = (show === undefined) ? !this.open : show;
    if (!this.open) { this.closeChest(); }
    this.refresh();
  },

  openChest: function (chest) {
    this.chest = chest;
    this.open = true;
    this.refresh();
  },

  closeChest: function () {
    if (!this.chest) { return; }
    this.chest = null;
    this.refresh();
    if (Game.running) { Game.render(); } // an emptied chest looks different on the map
  },

  takeAll: function () {
    if (!this.chest) { return; }
    var inv = Game.player.inventory;
    var full = false;
    for (var i = 0; i < this.chest.slots.length; i++) {
      if (this.chest.slots[i] && Container.quickMove(this.chest, i, inv) > 0) { full = true; }
    }
    if (full) { UI.show("Your bag is full."); }
    this.changed();
  },

  // After any move: redraw both grids and see if the ananas is in the bag.
  changed: function () {
    this.refresh();
    Game.checkWin();
  },

  _containers: function () {
    return { inv: Game.player && Game.player.inventory, chest: this.chest };
  },

  refresh: function () {
    var invWin = document.getElementById("inventory");
    var chestWin = document.getElementById("chest");
    invWin.hidden = !this.open || !Game.player;
    chestWin.hidden = !this.chest;
    document.getElementById("windows").classList.toggle("modal", !!this.chest);
    if (Game.player) { this._renderGrid(document.getElementById("inv-grid"), Game.player.inventory, "inv"); }
    if (this.chest) { this._renderGrid(document.getElementById("chest-grid"), this.chest, "chest"); }
    this.hideTooltip();
  },

  _renderGrid: function (gridEl, container, name) {
    var self = this;
    gridEl.innerHTML = "";
    gridEl.style.gridTemplateColumns = "repeat(" + container.cols + ", 52px)";
    container.slots.forEach(function (stack, index) {
      var slot = document.createElement("div");
      slot.className = "slot";
      slot.dataset.container = name;
      slot.dataset.index = index;

      if (stack) {
        var item = Items.get(stack.id);
        slot.draggable = true;
        slot.classList.add("filled", "rarity-" + item.rarity);
        var glyph = document.createElement("span");
        glyph.className = "glyph";
        glyph.textContent = item.glyph;
        glyph.style.color = item.color;
        slot.appendChild(glyph);
        if (stack.qty > 1) {
          var qty = document.createElement("span");
          qty.className = "qty";
          qty.textContent = stack.qty;
          slot.appendChild(qty);
        }
        slot.addEventListener("dragstart", function (e) {
          e.dataTransfer.setData("text/plain", name + ":" + index);
          e.dataTransfer.effectAllowed = "move";
          slot.classList.add("dragging");
          self.hideTooltip();
        });
        slot.addEventListener("dragend", function () { slot.classList.remove("dragging"); });
        slot.addEventListener("mousemove", function (e) { self.showTooltip(stack, e); });
        slot.addEventListener("mouseleave", function () { self.hideTooltip(); });
        slot.addEventListener("click", function (e) { if (e.shiftKey) { self.quickMove(name, index); } });
        slot.addEventListener("dblclick", function () { self.quickMove(name, index); });
      }

      slot.addEventListener("dragover", function (e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        slot.classList.add("over");
      });
      slot.addEventListener("dragleave", function () { slot.classList.remove("over"); });
      slot.addEventListener("drop", function (e) {
        e.preventDefault();
        var src = e.dataTransfer.getData("text/plain").split(":");
        self.move(src[0], parseInt(src[1]), name, index);
      });
      gridEl.appendChild(slot);
    });
  },

  // Move a stack between (or within) the bag and the open chest.
  move: function (srcName, srcIndex, dstName, dstIndex) {
    var c = this._containers();
    if (!c[srcName] || !c[dstName]) { return; }
    Container.transfer(c[srcName], srcIndex, c[dstName], dstIndex);
    this.changed();
  },

  quickMove: function (srcName, srcIndex) {
    var c = this._containers();
    var dstName = srcName === "inv" ? "chest" : "inv";
    if (!c[dstName]) { return; } // no chest open: nowhere to send it
    if (Container.quickMove(c[srcName], srcIndex, c[dstName]) > 0) {
      UI.show(dstName === "inv" ? "Your bag is full." : "The chest is full.");
    }
    this.changed();
  },

  showTooltip: function (stack, e) {
    var item = Items.get(stack.id);
    var t = this.tooltip;
    t.innerHTML = "";
    var name = document.createElement("div");
    name.className = "tt-name";
    name.textContent = item.name + (stack.qty > 1 ? " ×" + stack.qty : "");
    name.style.color = Items.RARITY[item.rarity].color;
    var meta = document.createElement("div");
    meta.className = "tt-meta";
    meta.textContent = item.rarity + " " + item.category.toLowerCase() + (item.maxStack > 1 ? " · stacks to " + item.maxStack : "");
    var desc = document.createElement("div");
    desc.className = "tt-desc";
    desc.textContent = item.desc;
    t.append(name, meta, desc);
    t.hidden = false;
    // Keep it on screen: flip to the other side of the cursor near the right or bottom edge.
    var x = e.clientX + 16, y = e.clientY + 16;
    if (x + t.offsetWidth > window.innerWidth - 8) { x = e.clientX - t.offsetWidth - 12; }
    if (y + t.offsetHeight > window.innerHeight - 8) { y = e.clientY - t.offsetHeight - 12; }
    t.style.left = x + "px";
    t.style.top = y + "px";
  },

  hideTooltip: function () {
    if (this.tooltip) { this.tooltip.hidden = true; }
  }
};
