// Part 2: the player, who waits for a key each turn.
// Part 3 (reworked): chests are opened with the interact key and looted through the chest window.
// The dungeon entrance (>) and the stairs (<) also need the interact key.
var Player = function (x, y) {
  Entity.call(this, x, y, "@", "#ff0");
  this.inventory = new Container("Inventory", 4, 4);
  // Something to start with.
  this.inventory.add("dagger", 1);
  this.inventory.add("bread", 3);
  this.inventory.add("torch", 2);
  this.inventory.add("gold", 15);
};
Player.prototype = Object.create(Entity.prototype);
Player.prototype.constructor = Player;

// Called by the engine when it's our turn: stop the engine and wait for a key.
Player.prototype.act = function () {
  Game.engine.lock();
  Game.render();
  window.addEventListener("keydown", this);
};

// Keys -> index into ROT.DIRS[8] (0 = up, then clockwise).
Player.KEY_MAP = {
  ArrowUp: 0, PageUp: 1, ArrowRight: 2, PageDown: 3,
  ArrowDown: 4, End: 5, ArrowLeft: 6, Home: 7,
  "8": 0, "9": 1, "6": 2, "3": 3, "2": 4, "1": 5, "4": 6, "7": 7,
  w: 0, d: 2, s: 4, a: 6
};
Player.INTERACT_KEYS = { e: true, E: true, Enter: true, " ": true };

// The player object is its own keydown listener (see addEventListener above).
Player.prototype.handleEvent = function (e) {
  if (UI.isBlocking()) { return; } // a menu or window is open: keys belong to it

  if (Player.INTERACT_KEYS[e.key]) {
    e.preventDefault();
    this._interact();
    return;
  }

  if (!(e.key in Player.KEY_MAP)) { return; }
  e.preventDefault();

  var diff = ROT.DIRS[8][Player.KEY_MAP[e.key]];
  var newX = this._x + diff[0];
  var newY = this._y + diff[1];

  var cell = Game.cellAt(newX, newY);
  if (!cell) { return; }
  if (!cell.passable) {
    if (cell.type === "mountain") { UI.show("The mountains are too steep to climb."); }
    return;
  }
  if (Game.beingAt(newX, newY)) { return; } // can't walk into Pedro

  UI.clear();
  window.removeEventListener("keydown", this);
  this._moveTo(newX, newY);
  this._describeHere();
  Game.engine.unlock();
};

// Say what's under the player's feet, and how to use it.
Player.prototype._describeHere = function () {
  var key = this._x + "," + this._y;
  var cell = Game.cellAt(this._x, this._y);
  var chest = Game.level.chests[key];
  if (chest) {
    UI.show(chest.isEmpty() ? "An empty chest." : "A chest. Press E to open it.");
  } else if (cell.type === "entrance") {
    UI.show("A dark stairway leads down into a dungeon. Press E to enter.");
  } else if (cell.type === "stairsUp") {
    UI.show("Stairs lead back up to the surface. Press E to climb out.");
  } else if (cell.type === "door") {
    UI.show("You pass through a door.");
  }
};

// The interact key: open a chest, go down the entrance, or climb the stairs.
Player.prototype._interact = function () {
  var key = this._x + "," + this._y;
  var cell = Game.cellAt(this._x, this._y);
  var chest = Game.level.chests[key];
  if (chest) {
    InventoryUI.openChest(chest);
  } else if (cell.type === "entrance") {
    window.removeEventListener("keydown", this);
    Game.enterDungeon();
  } else if (cell.type === "stairsUp") {
    window.removeEventListener("keydown", this);
    Game.leaveDungeon();
  } else {
    UI.show("There's nothing here to use.");
  }
};
