// A generic fantasy item list, and the loot table that fills the dungeon's chests.
// maxStack > 1 means the item stacks in one inventory slot up to that many.
var Items = {
  RARITY: {
    common:   { weight: 60, color: "#d8d8d8" },
    uncommon: { weight: 28, color: "#6fdc6f" },
    rare:     { weight: 10, color: "#6fa8ff" },
    epic:     { weight: 2,  color: "#c77dff" }
  },

  list: [
    // Weapons
    { id: "dagger",        name: "Dagger",               glyph: ")", color: "#c0c0c0", category: "Weapon",    rarity: "common",   maxStack: 1,   desc: "A short blade. Quick, quiet and easy to hide." },
    { id: "short_sword",   name: "Short Sword",          glyph: ")", color: "#d0d0e0", category: "Weapon",    rarity: "common",   maxStack: 1,   desc: "A reliable one-handed sword." },
    { id: "longsword",     name: "Longsword",            glyph: ")", color: "#e8e8ff", category: "Weapon",    rarity: "uncommon", maxStack: 1,   desc: "A knight's blade, balanced and keen." },
    { id: "battle_axe",    name: "Battle Axe",           glyph: ")", color: "#c89060", category: "Weapon",    rarity: "uncommon", maxStack: 1,   desc: "Heavy, brutal, and very good at doors." },
    { id: "war_hammer",    name: "War Hammer",           glyph: ")", color: "#a0a0a0", category: "Weapon",    rarity: "uncommon", maxStack: 1,   desc: "Crushes armour like tin." },
    { id: "spear",         name: "Spear",                glyph: "/", color: "#c8a46e", category: "Weapon",    rarity: "common",   maxStack: 1,   desc: "Keeps trouble at arm's length, and then some." },
    { id: "shortbow",      name: "Shortbow",             glyph: "}", color: "#b07a40", category: "Weapon",    rarity: "common",   maxStack: 1,   desc: "A simple hunting bow." },
    { id: "arrows",        name: "Arrows",               glyph: "|", color: "#c8a46e", category: "Ammo",      rarity: "common",   maxStack: 50,  qty: [5, 20], desc: "Fletched with grey goose feathers." },
    { id: "bolts",         name: "Crossbow Bolts",       glyph: "|", color: "#9a9a9a", category: "Ammo",      rarity: "uncommon", maxStack: 50,  qty: [5, 15], desc: "Short, heavy, iron-tipped." },
    { id: "flame_blade",   name: "Flametongue",          glyph: ")", color: "#ff7030", category: "Weapon",    rarity: "epic",     maxStack: 1,   desc: "Its edge glows like a forge and never cools." },

    // Armour
    { id: "leather_cap",   name: "Leather Cap",          glyph: "[", color: "#a0703c", category: "Armour",    rarity: "common",   maxStack: 1,   desc: "Better than nothing. Slightly." },
    { id: "iron_helm",     name: "Iron Helm",            glyph: "[", color: "#b0b0b8", category: "Armour",    rarity: "uncommon", maxStack: 1,   desc: "A dented but sturdy helmet." },
    { id: "leather_armor", name: "Leather Armour",       glyph: "[", color: "#a0703c", category: "Armour",    rarity: "common",   maxStack: 1,   desc: "Boiled leather, light and quiet." },
    { id: "chainmail",     name: "Chainmail",            glyph: "[", color: "#c0c0d0", category: "Armour",    rarity: "uncommon", maxStack: 1,   desc: "Thousands of tiny rings. Jingles a bit." },
    { id: "plate_armor",   name: "Plate Armour",         glyph: "[", color: "#e0e0f0", category: "Armour",    rarity: "rare",     maxStack: 1,   desc: "Gleaming steel plates. You'll hear yourself coming." },
    { id: "wooden_shield", name: "Wooden Shield",        glyph: "]", color: "#b07a40", category: "Armour",    rarity: "common",   maxStack: 1,   desc: "Oak boards bound with iron." },
    { id: "iron_shield",   name: "Iron Shield",          glyph: "]", color: "#b0b0b8", category: "Armour",    rarity: "uncommon", maxStack: 1,   desc: "Heavy, but it stops arrows." },
    { id: "boots",         name: "Traveller's Boots",    glyph: "[", color: "#8a6040", category: "Armour",    rarity: "common",   maxStack: 1,   desc: "Worn soft from many roads." },
    { id: "gauntlets",     name: "Gauntlets",            glyph: "[", color: "#a0a0a8", category: "Armour",    rarity: "uncommon", maxStack: 1,   desc: "Steel gloves with leather palms." },
    { id: "elven_cloak",   name: "Elven Cloak",          glyph: "(", color: "#5fd08f", category: "Armour",    rarity: "rare",     maxStack: 1,   desc: "It seems to shift colour to match its surroundings." },

    // Potions
    { id: "potion_heal",   name: "Healing Potion",       glyph: "!", color: "#ff4a5a", category: "Potion",    rarity: "common",   maxStack: 10,  qty: [1, 3], desc: "Tastes of cherries and iron. Closes wounds." },
    { id: "potion_mana",   name: "Mana Potion",          glyph: "!", color: "#4a7aff", category: "Potion",    rarity: "uncommon", maxStack: 10,  qty: [1, 2], desc: "Fizzes with arcane energy." },
    { id: "antidote",      name: "Antidote",             glyph: "!", color: "#7ae05a", category: "Potion",    rarity: "common",   maxStack: 10,  qty: [1, 2], desc: "Cures most poisons, and some hangovers." },
    { id: "potion_str",    name: "Potion of Strength",   glyph: "!", color: "#ffb030", category: "Potion",    rarity: "rare",     maxStack: 5,   desc: "For a while, you could lift an ox." },

    // Scrolls & books
    { id: "scroll_fire",   name: "Scroll of Fireball",   glyph: "?", color: "#ff7030", category: "Scroll",    rarity: "uncommon", maxStack: 10,  desc: "Read aloud, then duck." },
    { id: "scroll_tele",   name: "Scroll of Teleport",   glyph: "?", color: "#c77dff", category: "Scroll",    rarity: "rare",     maxStack: 10,  desc: "Takes you somewhere else. Anywhere else." },
    { id: "scroll_ident",  name: "Scroll of Identify",   glyph: "?", color: "#e8e8a0", category: "Scroll",    rarity: "common",   maxStack: 10,  qty: [1, 2], desc: "Reveals the true nature of an item." },
    { id: "spellbook",     name: "Dusty Spellbook",      glyph: "+", color: "#9a6aff", category: "Scroll",    rarity: "rare",     maxStack: 1,   desc: "Most pages are blank. The rest are unsettling." },

    // Food
    { id: "bread",         name: "Loaf of Bread",        glyph: "%", color: "#e0b070", category: "Food",      rarity: "common",   maxStack: 20,  qty: [1, 3], desc: "A bit stale, still filling." },
    { id: "apple",         name: "Apple",                glyph: "%", color: "#ff5040", category: "Food",      rarity: "common",   maxStack: 20,  qty: [1, 5], desc: "Crisp and red." },
    { id: "cheese",        name: "Wheel of Cheese",      glyph: "%", color: "#ffd84a", category: "Food",      rarity: "common",   maxStack: 10,  desc: "Pungent. Very pungent." },
    { id: "dried_meat",    name: "Dried Meat",           glyph: "%", color: "#a05030", category: "Food",      rarity: "common",   maxStack: 20,  qty: [1, 4], desc: "Salty strips of something. Probably beef." },

    // Valuables
    { id: "gold",          name: "Gold Coins",           glyph: "$", color: "#ffd700", category: "Valuable",  rarity: "common",   maxStack: 999, qty: [5, 60], desc: "Shiny and heavy." },
    { id: "silver_ring",   name: "Silver Ring",          glyph: "=", color: "#e0e0f0", category: "Valuable",  rarity: "uncommon", maxStack: 1,   desc: "A plain band with a tiny inscription." },
    { id: "ruby",          name: "Ruby",                 glyph: "*", color: "#ff2050", category: "Valuable",  rarity: "rare",     maxStack: 20,  desc: "A deep red gem." },
    { id: "emerald",       name: "Emerald",              glyph: "*", color: "#20e070", category: "Valuable",  rarity: "rare",     maxStack: 20,  desc: "A clear green gem." },
    { id: "sapphire",      name: "Sapphire",             glyph: "*", color: "#3070ff", category: "Valuable",  rarity: "rare",     maxStack: 20,  desc: "A cold blue gem." },
    { id: "amulet",        name: "Amulet of the Moon",   glyph: "\"", color: "#c0e0ff", category: "Valuable", rarity: "epic",     maxStack: 1,   desc: "Glows faintly when nobody is looking at it." },

    // Tools & misc
    { id: "torch",         name: "Torch",                glyph: "~", color: "#ffa030", category: "Tool",      rarity: "common",   maxStack: 10,  qty: [1, 3], desc: "Pitch-soaked rags on a stick." },
    { id: "rope",          name: "Coil of Rope",         glyph: "&", color: "#c8a46e", category: "Tool",      rarity: "common",   maxStack: 5,   desc: "Fifty feet of hemp rope." },
    { id: "lockpick",      name: "Lockpick",             glyph: "-", color: "#b0b0b8", category: "Tool",      rarity: "uncommon", maxStack: 20,  qty: [1, 4], desc: "Thin, bendy, and not entirely legal." },
    { id: "iron_key",      name: "Iron Key",             glyph: "-", color: "#9a9a9a", category: "Tool",      rarity: "uncommon", maxStack: 5,   desc: "It must open something down here." },
    { id: "bandage",       name: "Bandage",              glyph: "~", color: "#f0f0e0", category: "Tool",      rarity: "common",   maxStack: 20,  qty: [1, 4], desc: "Clean linen strips." },

    // The goal of the game
    { id: "ananas",        name: "The Ananas",           glyph: "A", color: "#ffe14a", category: "Quest",     rarity: "epic",     maxStack: 1,   desc: "Pedro's prized pineapple. Get it out of here!" }
  ],

  byId: {},

  get: function (id) { return this.byId[id]; },

  // Pick a random item (never the ananas), weighted by rarity.
  randomItem: function () {
    var weights = {};
    this.list.forEach(function (item) {
      if (item.category !== "Quest") { weights[item.id] = Items.RARITY[item.rarity].weight; }
    });
    return this.get(ROT.RNG.getWeightedValue(weights));
  },

  // A quantity to put in a chest for this item.
  randomQty: function (item) {
    if (item.maxStack === 1) { return 1; }
    var range = item.qty || [1, 1];
    return ROT.RNG.getUniformInt(range[0], range[1]);
  },

  // Fill a container with 2-5 random stacks.
  fillChest: function (container) {
    var count = ROT.RNG.getUniformInt(2, 5);
    for (var i = 0; i < count; i++) {
      var item = this.randomItem();
      container.add(item.id, this.randomQty(item));
    }
  }
};
Items.list.forEach(function (item) { Items.byId[item.id] = item; });
