// The overworld: terrain grown with cellular automata (ROT.Map.Cellular).
//   layer 1 decides land vs water,
//   layer 2 raises some land into hills,
//   layer 3 pushes the highest hills up into mountains (which can't be crossed).
// The dungeon entrance is placed on land the player can actually walk to.
var Overworld = {
  generate: function (W, H) {
    for (var attempt = 0; attempt < 20; attempt++) {
      var level = this._try(W, H);
      if (level) { return level; }
    }
    throw new Error("Could not generate a usable overworld");
  },

  // Run a cellular automaton and return a lookup "x,y" -> true for live cells.
  _cellular: function (W, H, fill, iterations, options) {
    var alive = {};
    var cellular = new ROT.Map.Cellular(W, H, options);
    cellular.randomize(fill);
    for (var i = 0; i < iterations - 1; i++) { cellular.create(); }
    cellular.create(function (x, y, value) {
      if (value) { alive[x + "," + y] = true; }
    });
    return alive;
  },

  _try: function (W, H) {
    var smooth = { born: [5, 6, 7, 8], survive: [4, 5, 6, 7, 8] };
    var land = this._cellular(W, H, 0.6, 5, smooth);
    var high = this._cellular(W, H, 0.45, 5, smooth);
    var peak = this._cellular(W, H, 0.42, 4, smooth);

    var cells = {};
    for (var x = 0; x < W; x++) {
      for (var y = 0; y < H; y++) {
        var key = x + "," + y;
        var type = "water";
        if (land[key]) {
          type = "plain";
          if (high[key]) { type = peak[key] ? "mountain" : "hill"; }
        }
        cells[key] = Tiles.make(type, x, y);
      }
    }

    // Start the player on a random plain, then flood-fill to see where they can walk.
    var plains = Object.keys(cells).filter(function (k) { return cells[k].type === "plain"; });
    if (plains.length < 100) { return null; }
    var startKey = plains[Math.floor(ROT.RNG.getUniform() * plains.length)];
    var dist = this._distances(cells, startKey, W, H);

    // The entrance goes on the reachable plain or hill farthest from the start.
    var entranceKey = null;
    var best = -1;
    var reachable = 0;
    for (var k in dist) {
      reachable++;
      var t = cells[k].type;
      if ((t === "plain" || t === "hill") && dist[k] > best) { best = dist[k]; entranceKey = k; }
    }
    if (reachable < 300 || best < 20) { return null; }

    var ep = entranceKey.split(",").map(Number);
    cells[entranceKey] = Tiles.make("entrance", ep[0], ep[1]);

    return {
      name: "overworld",
      cells: cells,
      chests: {},
      fog: false,
      start: startKey.split(",").map(Number),
      entrance: ep
    };
  },

  // Breadth-first search over passable cells (8 directions). Returns "x,y" -> steps.
  _distances: function (cells, startKey, W, H) {
    var dist = {};
    dist[startKey] = 0;
    var queue = [startKey];
    while (queue.length) {
      var key = queue.shift();
      var p = key.split(",").map(Number);
      for (var i = 0; i < 8; i++) {
        var nx = p[0] + ROT.DIRS[8][i][0];
        var ny = p[1] + ROT.DIRS[8][i][1];
        var nk = nx + "," + ny;
        if (nk in dist || !cells[nk] || !cells[nk].passable) { continue; }
        dist[nk] = dist[key] + 1;
        queue.push(nk);
      }
    }
    return dist;
  }
};
