// Shared bits for anything that stands on the map (the player and Pedro).
var Entity = function (x, y, ch, color) {
  this._x = x;
  this._y = y;
  this._ch = ch;
  this._color = color;
};

Entity.prototype.getX = function () { return this._x; };
Entity.prototype.getY = function () { return this._y; };
Entity.prototype.getChar = function () { return this._ch; };
Entity.prototype.getColor = function () { return this._color; };

// Move to (x, y). The screen is redrawn when the player's turn comes round,
// because what you can see depends on where everyone is.
Entity.prototype._moveTo = function (x, y) {
  this._x = x;
  this._y = y;
};
