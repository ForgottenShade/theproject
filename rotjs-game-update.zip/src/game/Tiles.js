// Every kind of ground in the game. Each map cell stores { type, ch, fg, bg, passable },
// built from these definitions with a little random colour variation for texture.
var Tiles = {
  // Overworld
  water:    { ch: "~", fg: "#5aa0e8", bg: "#12305a", passable: true,  vary: 18 },
  plain:    { ch: ".", fg: "#8fd07a", bg: "#1d3a1a", passable: true,  vary: 10, alt: '"' },
  hill:     { ch: "n", fg: "#c8ac6a", bg: "#3a3418", passable: true,  vary: 12 },
  mountain: { ch: "^", fg: "#e8e8e8", bg: "#56524e", passable: false, vary: 14 },
  entrance: { ch: ">", fg: "#ffffff", bg: "#7a2a10", passable: true,  vary: 0 },

  // Dungeon
  wood:     { ch: ".", fg: "#c08850", bg: "#3b2614", passable: true,  vary: 6, alt: "_" },
  stone:    { ch: ".", fg: "#9a9a9a", bg: "#2a2a2c", passable: true,  vary: 8, alt: "," },
  corridor: { ch: ".", fg: "#777777", bg: "#1c1c1e", passable: true,  vary: 6 },
  door:     { ch: "+", fg: "#e0a050", bg: "#4a2c10", passable: true,  vary: 0 },
  wall:     { ch: "#", fg: "#9c8670", bg: "#3a3028", passable: false, vary: 16 },
  stairsUp: { ch: "<", fg: "#ffffff", bg: "#2a2a2c", passable: true,  vary: 0 },

  // Make one cell of a given type. Colours are nudged randomly so large areas look textured.
  make: function (type, x, y) {
    var t = this[type];
    var cell = { type: type, ch: t.ch, fg: t.fg, bg: t.bg, passable: t.passable };
    if (t.vary) {
      cell.fg = ROT.Color.toHex(ROT.Color.randomize(ROT.Color.fromString(t.fg), t.vary));
      cell.bg = ROT.Color.toHex(ROT.Color.randomize(ROT.Color.fromString(t.bg), Math.round(t.vary / 2)));
    }
    if (t.alt && ROT.RNG.getUniform() < 0.15) { cell.ch = t.alt; }
    // Wood floors: darken every other row so they read as planks.
    if (type === "wood" && y % 2) {
      cell.bg = ROT.Color.toHex(ROT.Color.multiply(ROT.Color.fromString(cell.bg), [200, 200, 200]));
    }
    // Walls: a brick pattern, mortar lines on alternating columns per row.
    if (type === "wall" && (x + (y % 2) * 2) % 4 === 0) {
      cell.bg = ROT.Color.toHex(ROT.Color.multiply(ROT.Color.fromString(cell.bg), [170, 170, 170]));
    }
    return cell;
  }
};
