// The dungeon level. Part 1 of the tutorial (ROT.Map.Digger + boxes, now chests of loot), plus terrain:
// each room gets a wood or stone floor, corridors are rough stone, room exits become
// doors, and every wall that touches open ground is drawn with a brick texture.
var GameMap = {
  generate: function (W, H) {
    var cells = {};
    var freeCells = [];

    var digger = new ROT.Map.Digger(W, H);
    digger.create(function (x, y, value) {
      if (value) { return; } // walls are added below, only where they're visible
      var key = x + "," + y;
      cells[key] = Tiles.make("corridor", x, y);
      freeCells.push(key);
    });

    // Rooms: pick a floor material per room, and turn the room's exits into doors.
    digger.getRooms().forEach(function (room) {
      var material = ROT.RNG.getUniform() < 0.5 ? "wood" : "stone";
      for (var x = room.getLeft(); x <= room.getRight(); x++) {
        for (var y = room.getTop(); y <= room.getBottom(); y++) {
          cells[x + "," + y] = Tiles.make(material, x, y);
        }
      }
      room.getDoors(function (x, y) {
        cells[x + "," + y] = Tiles.make("door", x, y);
      });
    });

    // Walls: any solid cell next to open ground.
    for (var key in Object.assign({}, cells)) {
      var p = key.split(",").map(Number);
      for (var i = 0; i < 8; i++) {
        var wx = p[0] + ROT.DIRS[8][i][0];
        var wy = p[1] + ROT.DIRS[8][i][1];
        var wk = wx + "," + wy;
        if (!cells[wk] && wx >= 0 && wy >= 0 && wx < W && wy < H) {
          cells[wk] = Tiles.make("wall", wx, wy);
        }
      }
    }

    // Doors aren't good places for boxes or for starting.
    freeCells = freeCells.filter(function (k) { return cells[k].type !== "door"; });

    var level = { name: "dungeon", cells: cells, chests: {}, fog: true, memory: {} };
    this._generateChests(level, freeCells);

    // The way back up is where the player arrives.
    level.start = this.takeFreeCell(freeCells);
    cells[level.start.join(",")] = Tiles.make("stairsUp", level.start[0], level.start[1]);
    level.freeCells = freeCells;
    return level;
  },

  // Put 10 chests on random free cells, each filled with random loot.
  // The first one also gets the ananas (the box with the ananas, from tutorial parts 1 and 3).
  _generateChests: function (level, freeCells) {
    for (var i = 0; i < 10; i++) {
      var index = Math.floor(ROT.RNG.getUniform() * freeCells.length);
      var key = freeCells.splice(index, 1)[0];
      var chest = new Container("Chest", 4, 2);
      if (!i) { chest.add("ananas", 1); }
      Items.fillChest(chest);
      level.chests[key] = chest;
    }
  },

  // Pick (and remove) a random free cell, returned as [x, y].
  takeFreeCell: function (freeCells) {
    var index = Math.floor(ROT.RNG.getUniform() * freeCells.length);
    return freeCells.splice(index, 1)[0].split(",").map(Number);
  }
};
