// The Game object ties it all together: two levels (overworld and dungeon),
// each with its own scheduler, and one engine that runs whichever level you're on.
var Game = {
  WIDTH: 80,
  HEIGHT: 25,
  display: null,
  engine: null,
  player: null,
  pedro: null,
  overworld: null,
  dungeon: null,
  level: null,    // the level the player is on now
  running: false, // false before the first world and after winning or losing
  visible: {},    // cells the player can see this turn (dungeon only)

  init: function () {
    this.display = new ROT.Display({ width: this.WIDTH, height: this.HEIGHT, fontSize: 18 });
    document.getElementById("game").appendChild(this.display.getContainer());
  },

  // A brand new world. The dungeon is dug the first time you go in.
  newWorld: function () {
    if (this.engine) { this.engine.lock(); }
    if (this.player) { window.removeEventListener("keydown", this.player); }
    this.dungeon = null;
    this.pedro = null;
    this.running = true;

    this.overworld = Overworld.generate(this.WIDTH, this.HEIGHT);
    this.overworld.scheduler = new ROT.Scheduler.Simple();
    this.player = new Player(this.overworld.start[0], this.overworld.start[1]);
    this.overworld.scheduler.add(this.player, true);

    UI.show("Find the dungeon entrance (>) and press E on it. Mountains (^) can't be crossed. I opens your bag.");
    InventoryUI.refresh();
    this._switchTo(this.overworld, this.overworld.start);
  },

  enterDungeon: function () {
    if (!this.dungeon) {
      this.dungeon = GameMap.generate(this.WIDTH, this.HEIGHT);
      var pos = this._farCell(this.dungeon.freeCells, this.dungeon.start, 12);
      this.pedro = new Pedro(pos[0], pos[1]);
      this.dungeon.scheduler = new ROT.Scheduler.Simple();
      this.dungeon.scheduler.add(this.player, true);
      this.dungeon.scheduler.add(this.pedro, true);
    }
    UI.show("You enter the dungeon. The ananas is in one of the chests. Watch out for Pedro (P).");
    this._switchTo(this.dungeon, this.dungeon.start);
  },

  leaveDungeon: function () {
    UI.show("You climb back out into the daylight. Pedro stays below, waiting.");
    this._switchTo(this.overworld, this.overworld.entrance);
  },

  // Called whenever the player's bag changes: carrying the ananas wins the game.
  checkWin: function () {
    if (this.running && this.player.inventory.count("ananas") > 0) {
      this.running = false;
      this.engine.lock();
      window.removeEventListener("keydown", this.player);
      InventoryUI.closeChest();
      UI.show("Hooray! You got the ananas and won this game. Press Esc for the menu.");
      UI.banner("You found the ananas!", "Pedro will be furious.");
    }
  },

  gameOver: function (text) {
    this.running = false;
    this.engine.lock();
    window.removeEventListener("keydown", this.player);
    InventoryUI.closeChest();
    this.render();
    UI.show(text + " Press Esc for the menu.");
    UI.banner("Captured!", "Pedro got you before you got the ananas.");
  },

  // Put the player on `level` at `pos`, and run that level's scheduler.
  _switchTo: function (level, pos) {
    if (this.engine) { this.engine.lock(); }
    this.level = level;
    this.player._x = pos[0];
    this.player._y = pos[1];
    this.engine = new ROT.Engine(level.scheduler);
    this.engine.start(); // the player acts first, which draws the screen
  },

  // A random free cell at least `minDist` steps from `from`, if there is one.
  _farCell: function (freeCells, from, minDist) {
    var far = freeCells.filter(function (k) {
      var p = k.split(",").map(Number);
      return Math.abs(p[0] - from[0]) + Math.abs(p[1] - from[1]) >= minDist;
    });
    var list = far.length ? far : freeCells;
    var key = list[Math.floor(ROT.RNG.getUniform() * list.length)];
    freeCells.splice(freeCells.indexOf(key), 1);
    return key.split(",").map(Number);
  },

  cellAt: function (x, y) {
    return this.level.cells[x + "," + y];
  },

  beingAt: function (x, y) {
    if (this.level === this.dungeon && this.pedro && this.pedro.getX() === x && this.pedro.getY() === y) {
      return this.pedro;
    }
    return null;
  },

  // What the scenery at a cell looks like: ground, with a chest on top if there is one.
  _look: function (key) {
    var cell = this.level.cells[key];
    var look = { ch: cell.ch, fg: cell.fg, bg: cell.bg };
    var chest = this.level.chests[key];
    if (chest) {
      look.ch = "*";
      look.fg = chest.isEmpty() ? "#7a6a50" : "#ffd24a";
    }
    return look;
  },

  // Redraw the whole screen. In the dungeon, only what the player can see is drawn
  // as it is now; the rest is drawn from memory (dimmed), or not at all.
  render: function () {
    var level = this.level;
    this.display.clear();

    if (level.fog) {
      this.visible = Sight.compute(level, this.player.getX(), this.player.getY());
      for (var key in this.visible) {
        if (level.cells[key]) { level.memory[key] = this._look(key); }
      }
      for (var mkey in level.memory) {
        var p = mkey.split(",");
        var look = this.visible[mkey] ? level.memory[mkey] : Sight.dim(level.memory[mkey]);
        this.display.draw(parseInt(p[0]), parseInt(p[1]), look.ch, look.fg, look.bg);
      }
    } else {
      this.visible = null;
      for (var ckey in level.cells) {
        var q = ckey.split(",");
        var l = this._look(ckey);
        this.display.draw(parseInt(q[0]), parseInt(q[1]), l.ch, l.fg, l.bg);
      }
    }

    // Beings on top: always the player, Pedro only when in sight.
    var beings = [this.player];
    if (level === this.dungeon && this.pedro) { beings.push(this.pedro); }
    beings.forEach(function (b) {
      var bkey = b.getX() + "," + b.getY();
      if (this.visible && !this.visible[bkey]) { return; }
      var cell = level.cells[bkey];
      this.display.draw(b.getX(), b.getY(), b.getChar(), b.getColor(), cell ? cell.bg : null);
    }, this);
  }
};
